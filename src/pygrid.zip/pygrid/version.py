"""PyGRID version/build information."""

PYGRID_VERSION = "0.3.0-dev"
PYGRID_BUILD = "2026-09-14 conforming-fault-v3.19-straight-transverse-lines"
FAULT_GEOMETRY_REVISION = "CONFORM_V3_19_STRAIGHT_TRANSVERSE_LINES"


def version_text():
    return f"PyGRID {PYGRID_VERSION} | Build: {PYGRID_BUILD} | Fault geometry: {FAULT_GEOMETRY_REVISION}"


def print_banner():
    line = "=" * 72
    print(line)
    print(f" PyGRID {PYGRID_VERSION}")
    print(f" Build: {PYGRID_BUILD}")
    print(f" Fault geometry: {FAULT_GEOMETRY_REVISION}")
    print(line)
